# ASP.NET-Core-MVC-Login-and-Registration-using-Identity
This project required the design of a master user account database interfaced by an API that will allow users to logon to the various applications they use with a single username and password.
The project is built with ASP.NET Core MVC 
The user register and login on the Application can be assessed directly on the web browser.

The Database is created using SQL Server through Microsoft SQL Management Studio. In the SQL Server, a Database is created for the Application for the storage of users data.

To get users data as the register, Sql Server engine is implemented and the connection string for the data source is added to the appsetting.json in the application.
